//===============================================
//Author : Gavin Harper
//Date   : 10/30/2026
//Desc   : This is to store colors
//===============================================
package com.example.homework01_gh_rgbslider;

import java.util.ArrayList;

public class ColorInfo
{
    //Will be the color class to store color data

    private int Red;

    private int Green;

    private int Blue;

    private String HexRep;


    //Constructors
    public ColorInfo()
    {

    }

    public ColorInfo(int red, int green, int blue, String HR)
    {
        Red = red;
        Green = green;
        Blue = blue;
        HexRep = HR;
    }

    //Getters and setters
    public int getRed()
    {
        return Red;
    }
    public int getGreen()
    {
        return Green;
    }
    public int getBlue()
    {
        return Blue;
    }
    public String getHexRep()
    {
        return HexRep;
    }

    public void setRed(int red)
    {
        Red = red;
    }
    public void setGreen(int green)
    {
        Green = green;
    }
    public void setBlue(int blue)
    {
        Blue = blue;
    }
    public void setHexRep(String hexRep)
    {
        HexRep = hexRep;
    }
}
