
//===============================================
//Author : Gavin Harper
//Date   : 10/30/2026
//Desc   : this java class is to make the main screen
//         with rgb sliders and a save button and list
//===============================================

package com.example.homework01_gh_rgbslider;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{

    SeekBar sb_j_main_RedBar;
    SeekBar sb_j_main_BlueBar;
    SeekBar sb_j_main_GreenBar;

    ListView lv_j_main_ColorList;
    Button btn_j_main_SaveColor;
    TextView tv_j_main_HexRepr;
    TextView tv_j_main_Red;
    TextView tv_j_main_Blue;
    TextView tv_j_main_Green;
    TextView tv_j_main_RGBTitle;

    Boolean BlackOrWhiteText;

    View v_j_main_BGColor;

    ColorListAdapter clAdapter;
    private ArrayList<ColorInfo> loc;


    //Testing my listview
    //String[] test = {"One", "two","hello","Bye"};
    private ArrayList<ColorInfo> ListOfColors;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sb_j_main_RedBar = findViewById(R.id.sb_v_main_RedBar);
        sb_j_main_GreenBar = findViewById(R.id.sb_v_main_GreenBar);
        sb_j_main_BlueBar = findViewById(R.id.sb_v_main_BlueBar);

        lv_j_main_ColorList = findViewById(R.id.lv_v_main_ColorList);

        btn_j_main_SaveColor = findViewById(R.id.btn_v_main_saveColor);

        tv_j_main_HexRepr = findViewById(R.id.tv_v_main_HexRepr);
        tv_j_main_Red = findViewById(R.id.tv_v_main_Red);
        tv_j_main_Green = findViewById(R.id.tv_v_main_Green);
        tv_j_main_Blue = findViewById(R.id.tv_v_main_Blue);
        tv_j_main_RGBTitle = findViewById(R.id.tv_v_main_RGBTitle);

        v_j_main_BGColor = findViewById(R.id.v_v_main_BGColor);
        loc = new ArrayList<>();



        //Set the max of the bar to 255 and make it start at 0;
        sb_j_main_RedBar.setMax(255);
        sb_j_main_BlueBar.setMax(255);
        sb_j_main_GreenBar.setMax(255);
        sb_j_main_RedBar.setProgress(255);
        sb_j_main_BlueBar.setProgress(255);
        sb_j_main_GreenBar.setProgress(255);


        //Testing my listview
        //ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, test);
        //lv_j_main_ColorList.setAdapter(adapter);

        clAdapter = new ColorListAdapter(this, loc);
        lv_j_main_ColorList.setAdapter(clAdapter);

        sb_j_main_RedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                if(fromUser)
                {
                    tv_j_main_Red.setText("Red: " + progress);
                    HexUpdate();
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_j_main_GreenBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                if(fromUser)
                {
                    tv_j_main_Green.setText("Green: "+ progress);
                    HexUpdate();
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_j_main_BlueBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                if(fromUser)
                {
                    tv_j_main_Blue.setText("Blue: "+ progress);
                    HexUpdate();
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        AddColorButtonClickEvent();
        ListItemClickEvent();
    }


    private void AddColorButtonClickEvent()
    {
        btn_j_main_SaveColor.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)

            {
                int r = sb_j_main_RedBar.getProgress();
                int g = sb_j_main_GreenBar.getProgress();
                int b = sb_j_main_BlueBar.getProgress();


                //I learned this is a way to do hex.
                //I learned that String.format is a way to build hex strings
                //The # is for Hexs
                //The %X is for turning integers into a hex and being uppercased
                //The 0 is for padding so that if given 0-9 it is 01 or 02 ect
                //The 2 is for the width of of the hex - 2 give two digits, 5 would be 00005

                //I am sure there are other ways to do this, this is the way i found when looking around
                //A different way I could think is dividing the number by 16 for the first number/letter, and then the left over could be turned into the second number /letter

                String hex = String.format("#%02X%02X%02X", r, g, b);

                tv_j_main_HexRepr.setText("Hex Representation: " + hex);

                ColorInfo newColor = new ColorInfo(r,g,b,hex);
                loc.add(newColor);

                //I learned this is the way to notify the adapter that the list got changed.
                clAdapter.notifyDataSetChanged();

                //The directions say when the save color button is pressed, make the bars reset
                sb_j_main_RedBar.setProgress(255);
                sb_j_main_GreenBar.setProgress(255);
                sb_j_main_BlueBar.setProgress(255);
                HexUpdate();
                tv_j_main_Red.setText("Red: 255");
                tv_j_main_Green.setText("Green: 255");
                tv_j_main_Blue.setText("Blue: 255");



            }
        });
    }


    private void HexUpdate()
    {
        int r = sb_j_main_RedBar.getProgress();
        int g = sb_j_main_GreenBar.getProgress();
        int b = sb_j_main_BlueBar.getProgress();
        int TextColor;
        String hex = String.format("#%02X%02X%02X", r, g, b);

        tv_j_main_HexRepr.setText("Hex Representation: " + hex);
        v_j_main_BGColor.setBackgroundColor(android.graphics.Color.parseColor(hex));

        BlackOrWhiteText = BlackTextColorChange(sb_j_main_RedBar.getProgress(),sb_j_main_GreenBar.getProgress(),sb_j_main_BlueBar.getProgress());

        if (BlackOrWhiteText == true)
        {
            //Turn the text black
            TextColor = Color.BLACK;
            tv_j_main_Red.setTextColor(TextColor);
            tv_j_main_Green.setTextColor(TextColor);
            tv_j_main_Blue.setTextColor(TextColor);
            tv_j_main_HexRepr.setTextColor(TextColor);
            tv_j_main_RGBTitle.setTextColor(TextColor);
        }
        else
        {
            //turn the text white
            TextColor = Color.WHITE;
            tv_j_main_Red.setTextColor(TextColor);
            tv_j_main_Green.setTextColor(TextColor);
            tv_j_main_Blue.setTextColor(TextColor);
            tv_j_main_HexRepr.setTextColor(TextColor);
            tv_j_main_RGBTitle.setTextColor(TextColor);
        }

    }
    private void ListItemClickEvent()
    {
        //Look and see when I click on an item in my list
        //Depending on which one, set the bars to that color
        lv_j_main_ColorList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                ColorInfo Info = loc.get(position);
                sb_j_main_RedBar.setProgress(Info.getRed());
                sb_j_main_GreenBar.setProgress(Info.getGreen());
                sb_j_main_BlueBar.setProgress(Info.getBlue());
                HexUpdate();
                tv_j_main_Red.setText("Red: " + Info.getRed());
                tv_j_main_Green.setText("Green: "+ Info.getGreen());
                tv_j_main_Blue.setText("Blue: "+ Info.getBlue());



            }
        });
    }
    private boolean BlackTextColorChange(int r, int g, int b)
    {
        //I learned this while researching

        // Yiq refers to
        // Y = Luma which refers to brightness
        // i = In-Phase which is the blue to orange color phase
        // q = quadrant which is the purple to green color phase

        //I learned that the human eyes are most sensitive to green, followed by red and blue
        //In this formula, We give the weight of green more weight than red, and red more weight than green.
        // int yiq = (r * 299 + g * 587 + b * 114) / 1000;
        //we divide by 1000 because it gets us back to the 0-255 range. We can see if a color is
        //bright by seeing if the color yiq score is greater than 128. If it is, we turn the text black
        //If it is less than a yiq score of 128, we turn the text white.


        int yiq = (r * 299 + g * 587 + b * 114) / 1000;
        if(yiq >= 128)
        {
            //Our color is light, turn the text to black
            return true;
        }
        else
        {
            //our color is dark, turn the text to white
            return false;
        }
    }


}