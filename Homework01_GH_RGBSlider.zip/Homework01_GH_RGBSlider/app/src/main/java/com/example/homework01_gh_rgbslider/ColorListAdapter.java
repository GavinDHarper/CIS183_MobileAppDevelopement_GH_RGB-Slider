//===============================================
//Author : Gavin Harper
//Date   : 10/30/2026
//Desc   : This is to make the view for the list and
//         the components that go into it
//===============================================

package com.example.homework01_gh_rgbslider;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ColorListAdapter extends BaseAdapter
{
    Context context;

    ArrayList<ColorInfo> loc;

    public ColorListAdapter(Context c, ArrayList<ColorInfo> listoc)
    {
        context = c;
        loc = listoc;
    }

    @Override
    public int getCount() {
        return loc.size();
    }

    @Override
    public Object getItem(int position) {
        return loc.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
        {
            //Only do this if the first is null
            LayoutInflater mInflater = (LayoutInflater) context.getSystemService(MainActivity.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.colorlistviewcell, null);
        }
        //Find the gui elements for my custom view
        TextView RedValue = convertView.findViewById(R.id.tv_v_cell_Red);
        TextView GreenValue = convertView.findViewById(R.id.tv_v_cell_Green);
        TextView BlueValue = convertView.findViewById(R.id.tv_v_cell_Blue);
        TextView HexCode = convertView.findViewById(R.id.tv_v_cell_Hex);

        //get data for this color from our loc
        //we can access different elements based off the position value passed
        //to this function

        ColorInfo ThisColor = loc.get(position);

        //set the gui for the custom color cell
        RedValue.setText("Red : " + Integer.toString(ThisColor.getRed()));
        GreenValue.setText("Green : " + Integer.toString(ThisColor.getGreen()));
        BlueValue.setText("Blue : " + Integer.toString(ThisColor.getBlue()));
        HexCode.setText("Hex Code : " + ThisColor.getHexRep());
        convertView.setBackgroundColor(android.graphics.Color.parseColor(ThisColor.getHexRep()));

        boolean TextColorBool = BlackOrWhiteText(ThisColor.getRed(),ThisColor.getBlue(),ThisColor.getGreen());
        int TextColor;

        if (TextColorBool == true)
        {
            TextColor = Color.BLACK;
            RedValue.setTextColor(TextColor);
            GreenValue.setTextColor(TextColor);
            BlueValue.setTextColor(TextColor);
            HexCode.setTextColor(TextColor);
        }
        else
        {
            TextColor = Color.WHITE;
            RedValue.setTextColor(TextColor);
            GreenValue.setTextColor(TextColor);
            BlueValue.setTextColor(TextColor);
            HexCode.setTextColor(TextColor);
        }


        return convertView;
    }

    //Make the text color black or white
    private boolean BlackOrWhiteText(int r, int g, int b)
    {
        int yiq = (r * 299 + g * 587 + b * 114) / 1000;
        if(yiq >= 128)
        {
            //Our color is light, turn the text to black
            return true;
        }
        else
        {
            //our color is dark, turn the text to white
            return false;
        }
    }
}
